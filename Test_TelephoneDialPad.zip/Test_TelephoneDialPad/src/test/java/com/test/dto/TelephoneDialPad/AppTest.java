package com.test.dto.TelephoneDialPad;

import java.util.LinkedList;

import com.test.dto.TelephoneDialPad.TelephoneDialPad;

import junit.framework.Assert;
import junit.framework.TestCase;

public class AppTest 
extends TestCase
{
	LinkedList<String> expectedList = new LinkedList();
	//Below are test case 1-5 positive test cases where in the expected results are set based on the TelephoneDialPad functionality
	public void testCase1(){
		expectedList.add("0");

		System.out.println("Running testcase 1, dial 0");
		System.out.println("testcase 5, dail 0, Response received: " + TelephoneDialPad.retrieveCombinations("0"));
		Assert.assertEquals(true,TelephoneDialPad.retrieveCombinations("0").equals(expectedList));
		System.out.println("Result: testcase 1 Passed");
	}
	public void testCase2(){
		expectedList.add("1");

		System.out.println("Running testcase 2, dial 1");
		System.out.println("testcase 5, dail 1, Response received: " + TelephoneDialPad.retrieveCombinations("1"));
		Assert.assertEquals(true,TelephoneDialPad.retrieveCombinations("1").equals(expectedList));
		System.out.println("Result: testcase 2 Passed");
	}
	public void testCase3(){
		expectedList.add("A");
		expectedList.add("B");
		expectedList.add("C");

		System.out.println("Running testcase 3, dial 2");
		System.out.println("testcase 5, dail 3, Response received: " + TelephoneDialPad.retrieveCombinations("2"));
		Assert.assertEquals(true,TelephoneDialPad.retrieveCombinations("2").equals(expectedList));
		System.out.println("Result: testcase 3 Passed");
	}
	public void testCase4(){
		expectedList.add("01");

		System.out.println("Running testcase 4, dial 01");
		System.out.println("testcase 5, dail 01, Response received: " + TelephoneDialPad.retrieveCombinations("01"));
		Assert.assertEquals(true,TelephoneDialPad.retrieveCombinations("01").equals(expectedList));
		System.out.println("Result: testcase 4 Passed");
	}
	public void testCase5(){
		expectedList.add("1A");
		expectedList.add("1B");
		expectedList.add("1C");

		System.out.println("Running testcase 5, dial 12");
		System.out.println("testcase 5, dail 12, Response received: " + TelephoneDialPad.retrieveCombinations("12"));
		Assert.assertEquals(true,TelephoneDialPad.retrieveCombinations("12").equals(expectedList));
		System.out.println("Result: testcase 5 Passed");
	}
	//A Negative test where in the expected result is set incorrectly intentionally
	public void testCase6(){
		expectedList.add("1A");
		expectedList.add("1B");
		expectedList.add("1C");

		System.out.println("Running testcase 6 (NEGATIVE TESTCASE), dial 18");
		System.out.println("testcase 6, dail 18, Response received: " + TelephoneDialPad.retrieveCombinations("18"));
		Assert.assertEquals(false,TelephoneDialPad.retrieveCombinations("18").equals(expectedList));
		System.out.println("Result: testcase 6 Passed");
	}
	
}
